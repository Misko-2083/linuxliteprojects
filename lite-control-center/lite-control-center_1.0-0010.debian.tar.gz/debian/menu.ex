?package(lite-control-center):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="lite-control-center" command="/usr/bin/lite-control-center"

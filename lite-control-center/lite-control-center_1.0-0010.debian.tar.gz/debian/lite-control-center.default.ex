# Defaults for lite-control-center initscript
# sourced by /etc/init.d/lite-control-center
# installed at /etc/default/lite-control-center by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
